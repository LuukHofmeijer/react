const newTheme = {
  colors: {
    primary: 'black',
    background: 'white',
    card: 'orange',
    text: 'white',
  },
};

export default newTheme;